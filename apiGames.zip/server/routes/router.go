package routes

import (
	"github.com/DuduNeves/dev-games.git/controllers"
	"github.com/gin-gonic/gin"
)

func ConfigRoutes(router *gin.Engine) *gin.Engine {
	main := router.Group("api/v1")
	{
		games := main.Group("games")
		{
			games.GET("/:id", controllers.ShowGames)
			games.GET("/", controllers.ShowGames)
			games.POST("/", controllers.ShowGames)
			games.PUT("/", controllers.ShowGames)
			games.DELETE("/:id", controllers.ShowGames)

		}
	}

	return router
}
